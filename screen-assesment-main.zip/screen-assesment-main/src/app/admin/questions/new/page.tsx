import { QuestionForm } from '../components/QuestionForm'

export default function NewQuestionPage() {
  return <QuestionForm mode="create" />
}
